<h1> SOBIA MD <img src="https://media.giphy.com/media/VgCDAzcKvsR6OM0uWg/giphy.gif" width="50"> </h1>

<br>

<img align="center" height="auto"
src="https://cardivo.vercel.app/api?name=SOBIA%20MD&description=A%20PAKISTANI%20BEST%20AND%20FASTEST%20WHATSAPP%20BOT%20BY%20UD%20TEAM&image=https://files.catbox.moe/m1rf91.jpg?v=4&backgroundColor=%23ecf0f1&github=Um4r719&pattern=leaf&colorPattern=%23eaeaea"/>

<br>
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

***`FORK REPO`***

  <a href="https://github.com/Sobxsparl/SOBIA-MD/fork"><img src="https://img.shields.io/badge/Fork%20Create-black?style=for-the-badge&logo=github" alt="FORK SOBIA MD" width="150"></a>


<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

### <br> `SOBIA MD WEBPAGE`
<p align="left">
<a href="https://sobia-md-pair.onrender.com/"><img height= "35" title="Author" src="https://img.shields.io/badge/WebPage-black?style=for-the-badge&logo=google"></a>
<p/>
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

### <br> `SOBIA MD SESSION`
<p align="left">
<a href="https://sobia-md-pair.onrender.com/pair"><img height= "35" title="Author" src="https://img.shields.io/badge/Session-black?style=for-the-badge&logo=render"></a>
<p/>
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

### <br> `HEROKU DEPLOYMENT`
<p align="left">
<a href="https://dashboard.heroku.com/new-app?template=https://github.com/Sobxsparl/SOBIA-MD"><img height= "35" title="Author" src="https://img.shields.io/badge/Deploy-purple?style=for-the-badge&logo=heroku"></a>
<p/>
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

### <br> `SUPPORT CHANNEL`
<p align="left">
<a href="https://www.whatsapp.com/channel/0029VaswGwq5a23yxeJ6YB3t"><img height= "35" title="Author" src="https://img.shields.io/badge/Join-black?style=for-the-badge&logo=whatsapp"></a>
<p/>
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

### <br> `INSTAGRAM`
<p align="left">
<a href="https://www.instagram.com/um4rxd"><img height= "35" title="Author" src="https://img.shields.io/badge/Follow-black?style=for-the-badge&logo=instagram"></a>
<p/>
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

<h1>OUR TEAM</h1>
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
<details>
<h6>Authors</h6>

<div align="center">
  
| [![UMAR REHMAN](https://github.com/Um4r719.png?lenght=50width=50)](https://github.com/Um4r719)|
|----|
| [ SOBIA BUTT ](https://github.com/Um4r719) |
| Co.Owner,Developer, Bug Fixer, Maintainer, Updates |
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
<br>
  
| [![Sobia Butt](https://github.com/Sobxsparl.png?lenght=50width=50)](https://github.com/Sobxsparl) |
|----|
| [ SOBIA BUTT ](https://github.com/Sobxsparl) |
|  Owner |
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
  </div>

</details>



